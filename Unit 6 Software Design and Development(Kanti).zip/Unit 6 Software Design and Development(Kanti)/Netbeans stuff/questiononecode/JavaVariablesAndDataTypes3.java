
    import java.util.Date;

public class JavaVariablesAndDataTypes3{

     public static void main(String []args){
        
        
        Date date1 = new Date(); 
        Date date2 = new Date(); 
        
        long time1 = date1.getTime();
    	long time2 = date2.getTime();
		long diff = time2 - time1;
        
		System.out.println("Difference in days = " + diff/(1000*60*60*24));
        
     }
}
//The program prints “Difference in date = and then it inputs user data and divides that value by 1,440,000

