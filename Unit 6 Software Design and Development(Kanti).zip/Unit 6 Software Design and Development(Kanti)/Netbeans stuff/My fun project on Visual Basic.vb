﻿Module Module1

    Sub Main()
        Dim Yo As String
        Dim UserName As String
        Yo = "I sense the presence of a human..."
        Console.WriteLine("State yo name cus")
        UserName = Console.ReadLine()
        Console.WriteLine(Yo & UserName)
        Dim Wassup As String
        Wassup = "Wassup Human Scum"
        Console.WriteLine(Wassup)
        Console.ReadLine()
        Console.WriteLine("oh its on byach")
    End Sub

End Module
