
package javavariablesTask1;

public class JavaVariablesTask1 {

   
    public static void main(String[] args) {
        String BookName = "The book who liked to give things very long names";
	 int NumberOfPages = 555;
	String Author = "StephenRB";
	 String PublishedDate = "30/9/1998";
	 String PublisherName = "StephenRB";
	 
         System.out.println("The name of the book is "+BookName );
         System.out.println("The number of pages is "+NumberOfPages);
         System.out.println("The Name of the Author is "+Author);
         System.out.println("The Published Date is " +PublishedDate);
         System.out.println("The name if the publisher is "+PublisherName);
    }
    
}
