
package iterationcode.java;


public class IterationCodeJava {


    public static void main(String[] args) {
    String [] studentName = new String [5];
    
    studentName[0] = "John Blunker";
    studentName[1] = "Jessica Beans";
    studentName[2] = "Sarah Brown";
    studentName[3] = "Nigel Smith";
    studentName[4] = "James McCarter";

    for(int i = 0; i < 5; i++)
    {
    System.out.println("Student Name: "+ studentName[i]);
    } 
    //This is an example of the bad way to do it
   /* System.out.println("Student Name: " + studentName[0]);
    System.out.println("Student Name: " + studentName[1]);
    System.out.println("Student Name: " + studentName[2]);
    System.out.println("Student Name: " + studentName[3]);
    System.out.println("Student Name: " + studentName[4]);*/
    }

}