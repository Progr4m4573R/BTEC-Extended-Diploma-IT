public class Books
public static void main(String[]args);{
	 String BookName = The book who liked to give things very l'ong names
	 Int NumberOfPages = 555
	String Author = StephenRB]
	 date PublishedDate = 30/09/1998
	 String PublisherName = StephenRB
	 system.out.println(The name of thhe book is )
}


