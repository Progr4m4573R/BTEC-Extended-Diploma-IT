public class AllDatatypes{
	public static void main(String[]args){
	Int = 18
	float = 0.4
	String = "Stephen"
	}

}

