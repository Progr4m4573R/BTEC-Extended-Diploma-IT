import java.util.Date;

public class JavaVariablesAndDataTypes{

     public static void main(String []args){
        
        
        Date date1 = new Date(); 
        Date date2 = new Date(); 
        
        long time1 = date1.getTime();
    	long time2 = date2.getTime();
		long diff = time2 - time1;
        
		System.out.println("Difference in days = " + diff/(1000*60*60*24));
        
