
public class JavaVariablesAndDataTypes{

     public static void main(String []args){
       
        String    firstName = "Bob ";
        
        String lastName  = "Flood";
        
        String    fullname  = firstName + lastName;
                
        byte    numberOfStudents = 18;
        
        int  distance = 64564;
        
        Double    PI = 3.14159265359;
   
        double  currency = '£';
        
        char    filmClassification = 'U';
        
        System.out.println("Full Name: " + fullname);
        System.out.println("Number of students: " + numberOfStudents);
        System.out.println("Distance: " + distance);
        System.out.println("PI: " + PI);
        System.out.println("Currency: " + currency);
        // The following line outputs: 
        //               85 the ASCII value of the character U.
        System.out.println("Film Classification: " + filmClassification);
     }
}
