
    import java.util.Date;

public class JavaVariablesAndDataTypes{

     public static void main(String []args){
        
        
        Date date1 = new Date(10,12,1); 
        Date date2 = new Date(10,12,20); 
        
        long time1 = date1.getTime();
    	long time2 = date2.getTime();
		long diff = time2 - time1;
        
		System.out.println("Difference in days = " + diff/(1000*60*60*24));
        
     }
}
//The program prints “Difference in date = and then it inputs user data and divides that value by 1,440,000

