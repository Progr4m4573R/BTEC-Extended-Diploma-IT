public class JavaVariablesAndDataTypes{

     public static void main(String []args){
        
      long startTime = System.currentTimeMillis();
      
      for(int i=0;i<50000;i++){
         String    string1 = "Java String Variable";
         String string2 = "Java String Variable"; 
      }
      
         long endTime = System.currentTimeMillis();
      
      System.out.println("Time taken for creation" 
      + " of String literals : "+ (endTime - startTime) 
      + " milli seconds" );      
      
      
      double startTime1 = System.currentTimeMillis();
      
      
      for(int i=0;i<50000;i++){
         String string3 = new String("Java String Variable");
         String string4 = new String("Java String Variable");
      }
      
      long endTime1 = System.currentTimeMillis();
      
      System.out.println("Time taken for creation" 
      + " of String objects : " + (endTime1 - startTime1)
      + " milli seconds");
            
     }
}

