
package prtaice.on.classes;


public class PrtaiceOnClasses {

   
   public static void main(String[] args) {
   int S = 0;
   do{
   System.out.println(S);
   S++;
   }while(S<+7);
   
    }
    
}
